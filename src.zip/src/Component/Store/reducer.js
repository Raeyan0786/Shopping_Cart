import React from 'react'



export default function reducer(post = [],action) {
  if(action.type==='ADD_TO_CART')
  {
      let cart=post.filter((item)=> item.id===action.payload.id)
      if(cart<1)
      {
          return [...post, action.payload]
      }
      else{
        return post;
      }
      
  }
  return post;
  
}


