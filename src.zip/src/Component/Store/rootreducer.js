import { combineReducers } from "redux";
import reducer from "../cart/reducer";

const rootreducer  = combineReducers({ reducer });

export default rootreducer;